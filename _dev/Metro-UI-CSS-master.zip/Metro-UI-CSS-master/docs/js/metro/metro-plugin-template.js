(function( $ ) {
    $.widget("metro.widget", {

        version: "1.0.0",

        options: {
        },

        _create: function(){
        },

        _destroy: function(){

        },

        _setOption: function(key, value){
            this._super('_setOption', key, value);
        }
    })
})( jQuery );

